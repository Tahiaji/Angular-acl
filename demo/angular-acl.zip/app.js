var app = angular.module('App', ['acl', 'ui.router']);
app.config(function(AclProvider) {
    AclProvider.config({
        storage: 'localStorage',
        storageKey: 'o2o',
        defaultRole: 'guest',
        defaultUser: {
          name: 'Guest'  
        },
        permissions: {
            guest: {
                actions: {
                    login: true
                }
            },
            user: {
                actions: {
                    logout: true,
                    edit: function(user, post){
                        return post && user.id == post.ownerId;
                    }
                },
            },
            student: {
                actions: {
                    edit: false,
                },
                roles: ['user']
            },
            expert: {
                actions: {},
                roles: ['user']
            }
        }
    });
});

app.controller('C1', function($scope, Acl) {
    $scope.post = {ownerId: 1};
    $scope.login = function(role) {
        var id = 1;
        if(role == 'user'){
            id = 1;
        }else if(role == 'expert'){
            id = 2;
        }
        Acl.login(role, {id:id, name: angular.uppercase(role)});
    }
    $scope.logout = function() {
        $scope.edited = false;
        Acl.logout();
    }
    $scope.edited = false;
    $scope.edit = function() {
        $scope.appUser = angular.copy(Acl.user);
        $scope.edited = true;
    }
    $scope.save = function() {
        $scope.edited = false;
        Acl.save($scope.appUser);
    }
    $scope.change = function() {
        $scope.post.ownerId = $scope.post.ownerId == 1 ? 2 : 1;
    }
    Acl.hasRole('admin');
    Acl.can('edit', $scope.post);
});

app.controller('C2', function($scope, Acl) {
    $scope.appUser = Acl.user;
});

app.run(function(Acl, $rootScope) {
    
});